import React, { useState, useEffect } from 'react';

const artists = [
  "The Beatles", "Bob Dylan", "Elvis Presley", "The Rolling Stones",
  "John Mayer", "Dashboard Confessional"
];

function App() {
  const [artist, setArtist] = useState('');

  useEffect(() => {
    const pickArtist = () => {
      const random = Math.floor(Math.random() * artists.length);
      setArtist(artists[random]);
    };
    pickArtist();
  }, []);

  return (
    <div style={{ fontFamily: 'cursive', textAlign: 'center', padding: '2rem' }}>
      <h1>🎵 Lu Lu Mu Daily Artist 🎵</h1>
      <h2>{artist}</h2>
    </div>
  );
}

export default App;
